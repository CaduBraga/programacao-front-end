# AboutMe

Este repositório contém um site pessoal criado rapidamente como atividade da Unidade Curricular (UC) de Programação Front End, ministrada pelo professor Kristian Erdmann. O objetivo principal foi praticar conceitos de responsividade com HTML e CSS, utilizando textos levemente genéricos.

---

## Sobre o Projeto

Este site é uma apresentação rápida sobre mim, com informações básicas e textos genéricos. O foco da atividade foi treinar a construção de layouts responsivos e a aplicação dos fundamentos de HTML e CSS.

---

## Tecnologias Utilizadas

- **HTML**  
- **CSS**

---

## Objetivo da Atividade

> Desenvolver um site pessoal simples, focando na responsividade, como proposta da UC de Programação Front End do professor Kristian Erdmann.
